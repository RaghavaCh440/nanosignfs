# === nanosignfs/config.py ===

# Replace this with your actual GPG key ID after running setup_cert.sh
GPG_KEY_ID = "YOUR_KEY_ID"

# Local storage path used by the FUSE filesystem
STORAGE_PATH = "/tmp/nanosignfs_storage"
